import net_gargoyle as ngr

ngr.interact()
ngr.printdb()
