import net_gargoyle as ngr

ngr.createtable()
ngr.interact()
ngr.insertstat()
